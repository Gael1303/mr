import os
import sys
import json
import urllib.request
import xbmcgui
import xbmcplugin
import random
import time

from xbmcaddon import Addon
from xbmcvfs import translatePath
from urllib.parse import urlencode, parse_qsl

addon = Addon()

# Obtenha a chave de API do TMDb inserida pelo usuário
tmdb_api_key = addon.getSetting("tmdb_api_key")

# Caso a chave de API do usuário esteja vazia, você pode definir uma chave padrão (opcional)
if not tmdb_api_key:
    tmdb_api_key = ''  # Chave padrão, se necessário

# Obtenha o número de vídeos por página
videos_per_page = int(addon.getSetting("videos_per_page"))

# Obtenha o limite de páginas (opcional)
page_limit = int(addon.getSetting("page_limit"))

# Use a chave de API obtida
TMDB_API_KEY = tmdb_api_key

# Get the plugin url in plugin:// notation.
URL = sys.argv[0]
# Get a plugin handle as an integer number.
HANDLE = int(sys.argv[1])
# Get addon base path
ADDON_PATH = translatePath(Addon().getAddonInfo('path'))
ICONS_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'icons')
FANART_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'fanart')

# Define as categorias e suas respectivas URLs
CATEGORIES = {
    'Lançamentos': 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/news.json',
    'Randomizados': 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/random.json',
    'Por Notas': 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/notas.json',
    'Coleções': 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/test.json',
    'Gêneros': 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/genre.json',
    '4K': 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/hq.json',
    '[COLOR gray][B]Buscar[/B][/COLOR]': 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/search.json'
}

ICONS = {
    'Lançamentos': 'special://home/addons/plugin.video.flix/resources/media/lançamentos.png',
    'Randomizados': 'special://home/addons/plugin.video.flix/resources/media/randomizados.png',
    'Por Notas': 'special://home/addons/plugin.video.flix/resources/media/por_notas.png',
    'Coleções': 'special://home/addons/plugin.video.flix/resources/media/colecoes.png',
    'Gêneros': 'special://home/addons/plugin.video.flix/resources/media/generos.png',
    '4K': 'special://home/addons/plugin.video.flix/resources/media/4k.png',
    '[COLOR gray][B]Buscar[/B][/COLOR]': 'special://home/addons/plugin.video.flix/resources/media/buscar.png'
}

# Define a constante para o número de categorias por página
CATEGORIES_PER_PAGE = 15
VIDEOS_PER_PAGE = videos_per_page  # Número de vídeos por página, baseado nas configurações do usuário


def fetch_data_from_url(url):
    """
    Faz a requisição HTTP para buscar o arquivo JSON hospedado em uma URL.
    """
    try:
        response = urllib.request.urlopen(url)
        data = response.read().decode('utf-8')
        return json.loads(data)
    except Exception as e:
        xbmcgui.Dialog().notification('Erro', f'Não foi possível buscar os dados: {e}', xbmcgui.NOTIFICATION_ERROR)
        return []

def get_url(action, **kwargs):
    """
    Gera a URL para ações do plugin.
    """
    base_url = f'{sys.argv[0]}?action={action}'
    for key, value in kwargs.items():
        base_url += f'&{key}={value}'
    return base_url

def get_videos_from_category(url):
    """
    Obtém a lista de vídeos a partir do arquivo JSON específico de uma categoria.
    """
    data = fetch_data_from_url(url)
    
    # Verifica se a chave 'movies' ou 'gêneros' está presente
    if 'movies' in data:
        return data['movies']
    elif 'gêneros' in data:
        return data['gêneros']
    
    return []  # Retorna uma lista vazia se não houver a chave 'movies' ou 'gêneros'

def get_movie_info_from_tmdb(tmdb_id):
    """
    Faz uma requisição à API do TMDb para obter informações detalhadas sobre o filme.
    """
    tmdb_url = f'https://api.themoviedb.org/3/movie/{tmdb_id}?api_key={TMDB_API_KEY}&language=pt-BR'
    try:
        response = urllib.request.urlopen(tmdb_url)
        data = response.read().decode('utf-8')
        return json.loads(data)
    except Exception as e:
        xbmcgui.Dialog().notification('Erro', f'Não foi possível obter dados do TMDb: {e}', xbmcgui.NOTIFICATION_ERROR)
        return None

def list_categories():
    """
    Lista as categorias disponíveis no plugin.
    """

    for category_name in CATEGORIES.keys():
        list_item = xbmcgui.ListItem(label=category_name)

        # Define as imagens locais para o item
        list_item.setArt({
            'icon': ICONS.get(category_name, 'default.png'),
            'fanart': ICONS.get(category_name, 'default.jpg')
        })

        # Cria a URL para chamar o plugin com a URL da categoria
        url = get_url(action='listing', category=category_name)
        is_folder = True

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, is_folder)

    xbmcplugin.endOfDirectory(HANDLE)

def list_generos():
    """
    Lista os gêneros disponíveis no plugin.
    """
    xbmcplugin.setPluginCategory(HANDLE, 'Gêneros de Filmes')
    xbmcplugin.setContent(HANDLE, 'videos')

    # Obtém a URL da categoria
    generos_url = CATEGORIES['Gêneros']

    # Busca os gêneros do arquivo JSON
    xbmc.log(f"Buscando dados de gêneros da URL: {generos_url}", xbmc.LOGINFO)
    generos_data = fetch_data_from_url(generos_url)

    if not generos_data:
        xbmc.log("Erro: Nenhum dado encontrado no arquivo JSON de gêneros.", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Erro', 'Nenhum gênero encontrado', xbmcgui.NOTIFICATION_ERROR)
        return

    # Verifica se a chave 'generos' está presente no JSON
    if 'generos' in generos_data:
        xbmc.log("Dado 'generos' encontrado no arquivo JSON.", xbmc.LOGINFO)
        for genero in generos_data['generos']:
            xbmc.log(f"Processando gênero: {genero['nome']}", xbmc.LOGINFO)
            list_item = xbmcgui.ListItem(label=genero['nome'])

            # Define as imagens para o item (opcional)
            list_item.setArt({
                'icon': os.path.join(ICONS_DIR, 'default.png'),
                'fanart': os.path.join(FANART_DIR, 'default.jpg')
            })

            # Cria a URL para listar os vídeos dentro do gênero
            url = get_url(action='listing', category=genero['nome'])
            is_folder = True

            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, is_folder)
    else:
        xbmc.log("Erro: A chave 'generos' não foi encontrada no arquivo JSON.", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Erro', 'Nenhum gênero encontrado no arquivo JSON', xbmcgui.NOTIFICATION_ERROR)

    xbmcplugin.endOfDirectory(HANDLE)
    
def list_colecoes():
    """
    Função que lista as coleções disponíveis no arquivo JSON.
    """
    xbmcplugin.setPluginCategory(HANDLE, 'Coleções')
    xbmcplugin.setContent(HANDLE, 'movies')
    
    url = CATEGORIES['Coleções']  # URL do arquivo JSON de coleções
    response = urllib.request.urlopen(url)  # Faz a requisição HTTP
    data = response.read().decode('utf-8')
    colecoes = json.loads(data)  # Carrega o conteúdo JSON

    # Verifica se a chave 'colecoes' está presente no JSON
    if 'colecoes' in colecoes:
        for colecao in colecoes['colecoes']:
            nome_colecao = colecao['nome']
            descricao = colecao['descricao']
            imagem = colecao['imagem']

            # Cria o item de lista para cada coleção
            list_item = xbmcgui.ListItem(label=nome_colecao)
            list_item.setArt({
                'icon': imagem,
                'fanart': imagem
            })
            
            # URL para listar os vídeos da coleção
            url = get_url(action='listar_videos_colecao', colecao=nome_colecao)
            is_folder = True

            # Adiciona o item à interface do Kodi
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE)

def listar_videos_colecao(colecao_nome):
    """
    Lista os vídeos de uma coleção específica.
    """
    xbmcplugin.setContent(HANDLE, 'movies')
    
    url = CATEGORIES['Coleções']  # URL do arquivo JSON de coleções
    response = urllib.request.urlopen(url)  # Faz a requisição HTTP
    data = response.read().decode('utf-8')
    colecoes = json.loads(data)

    # Encontrar a coleção correta
    for colecao in colecoes['colecoes']:
        if colecao['nome'] == colecao_nome:
            videos = colecao['videos']
            
            # Define a categoria com o nome da coleção atual
            xbmcplugin.setPluginCategory(HANDLE, colecao_nome)
            
            for video in videos:
                titulo = video['titulo']
                tmdb_id = video['tmdb_id']
                video_url = video['url']

                # Obtém informações do TMDb, se necessário
                tmdb_info = get_movie_info_from_tmdb(tmdb_id)

                # Cria o item de lista para o vídeo
                list_item = xbmcgui.ListItem(label=titulo)
                list_item.setArt({
                    'poster': f"https://image.tmdb.org/t/p/w500{tmdb_info['poster_path']}",
                    'fanart': f"https://image.tmdb.org/t/p/original{tmdb_info['backdrop_path']}"
                })

                # Adiciona informações adicionais
                info_tag = list_item.getVideoInfoTag()
                info_tag.setMediaType('movie')
                info_tag.setTitle(titulo)
                info_tag.setPlot(tmdb_info['overview'])
                info_tag.setYear(int(tmdb_info['release_date'].split('-')[0]) if tmdb_info.get('release_date') else 0)
                info_tag.setRating(tmdb_info.get('vote_average', 0))

                # Definir como item reproduzível
                list_item.setProperty('IsPlayable', 'true')

                # URL para reprodução do vídeo
                url = get_url(action='play', video=video_url, movie_id=tmdb_id)
                is_folder = False

                # Adicionar o item à interface
                xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE)

    

def list_videos(category_name, page=1):
    """
    Cria a lista de vídeos reproduzíveis na interface do Kodi para a categoria selecionada com paginação.
    """
    xbmcplugin.setPluginCategory(HANDLE, f'{category_name}')  # Define a categoria no título
    xbmcplugin.setContent(HANDLE, 'movies')

    # Verifica se a categoria é um gênero e obtém sua URL do JSON
    genero_data = fetch_data_from_url(CATEGORIES['Gêneros'])
    genero_url = None

    if genero_data and 'generos' in genero_data:
        for genero in genero_data['generos']:
            if genero['nome'].lower() == category_name.lower():  # Ignora diferenças de maiúsculas e minúsculas
                genero_url = genero['url']
                break

    if genero_url:
        # Se for um gênero, usar a URL específica do gênero
        category_url = genero_url
    else:
        # Caso contrário, usa a URL do dicionário de CATEGORIES
        category_url = CATEGORIES.get(category_name)

    if not category_url:
        xbmcgui.Dialog().notification('Erro', 'Categoria não encontrada!', xbmcgui.NOTIFICATION_ERROR)
        return

    # Busca os vídeos da categoria
    videos = get_videos_from_category(category_url)

    # Embaralha a lista de vídeos se a categoria for 'Randomizados'
    if category_name == 'Randomizados':
        random.shuffle(videos)
    else:
        # Ordena os vídeos em ordem decrescente por ano de lançamento
        videos = sorted(videos, key=lambda x: x.get('release_date', '1900-01-01'), reverse=True)

    total_videos = len(videos)
    start_index = (page - 1) * VIDEOS_PER_PAGE
    end_index = start_index + VIDEOS_PER_PAGE
    paginated_videos = videos[start_index:end_index]

    for video in paginated_videos:
        tmdb_info = get_movie_info_from_tmdb(video['tmdb_id'])
        if not tmdb_info:
            continue

        list_item = xbmcgui.ListItem(label=tmdb_info['title'])

        # Define imagens (poster, fanart, etc.)
        list_item.setArt({
            'poster': f"https://image.tmdb.org/t/p/w500{tmdb_info['poster_path']}",
            'fanart': f"https://image.tmdb.org/t/p/original{tmdb_info['backdrop_path']}"
        })

        # Adiciona informações adicionais
        info_tag = list_item.getVideoInfoTag()
        info_tag.setMediaType('movie')
        info_tag.setTitle(tmdb_info['title'])
        info_tag.setPlot(tmdb_info['overview'])
        info_tag.setYear(int(tmdb_info['release_date'].split('-')[0]) if tmdb_info.get('release_date') else 0)
        info_tag.setRating(tmdb_info.get('vote_average', 0))

        # Adiciona os gêneros à descrição do vídeo
        genres = [genre['name'] for genre in tmdb_info.get('genres', [])]
        info_tag.setGenres(genres)  # Define os gêneros na tag

        list_item.setProperty('IsPlayable', 'true')

        # Cria a URL para reproduzir o vídeo
        url = get_url(action='play', video=video['url'], movie_id=video['tmdb_id'])
        is_folder = False

        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, is_folder)

    # Adicionando a opção de 'Próxima Página'
    if end_index < total_videos:
        next_page_url = get_url(action='listing', category=category_name, page=page + 1)
        next_page_item = xbmcgui.ListItem(label=f'Próxima Página ({page + 1}/{(total_videos + VIDEOS_PER_PAGE - 1) // VIDEOS_PER_PAGE})')

        next_page_item.setArt({
            'icon': 'https://archive.org/download/1700740365615/1700740365615.png'  # Coloque aqui a URL da imagem do ícone
        })
        xbmcplugin.addDirectoryItem(HANDLE, next_page_url, next_page_item, True)

    # Definir métodos de ordenação com base na categoria
    if category_name == 'Lançamentos':
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    elif category_name == 'Por Notas':
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    else:
        # Ordenação padrão decrescente para outras categorias
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)

    xbmcplugin.endOfDirectory(HANDLE)



def play_video(video_url, movie_id):
    """
    Inicia a reprodução do vídeo selecionado.
    """
    tmdb_info = get_movie_info_from_tmdb(movie_id)
    if not tmdb_info:
        return

    # Configura a janela de reprodução
    play_item = xbmcgui.ListItem(path=video_url)
    play_item.setInfo(type="Video", infoLabels={"Title": tmdb_info['title'], "Genre": tmdb_info['genres'][0]['name'] if tmdb_info['genres'] else 'Desconhecido'})
    play_item.setArt({'poster': f"https://image.tmdb.org/t/p/w500{tmdb_info['poster_path']}", 'fanart': f"https://image.tmdb.org/t/p/original{tmdb_info['backdrop_path']}"})

    # Inicia o player
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)

def search_movies():
    """
    Permite que o usuário busque filmes na lista de filmes.
    """
    # Exibe um teclado para o usuário inserir o nome do filme
    keyboard = xbmc.Keyboard('', 'Digite o nome do filme:')
    keyboard.doModal()
    
    if keyboard.isConfirmed():
        search_query = keyboard.getText().lower()  # Obtém o texto digitado e converte para minúsculas
        if not search_query:
            return  # Se não houver texto, não faz nada

        # Carrega a lista de filmes da categoria "Randomizados"
        buscar_filmes_url = CATEGORIES['[COLOR gray][B]Buscar[/B][/COLOR]']
        videos = get_videos_from_category(buscar_filmes_url)

        # Filtra os vídeos com base na consulta de pesquisa
        filtered_videos = [video for video in videos if 'title' in video and search_query in video['title'].lower()]

        if filtered_videos:
            xbmcplugin.setPluginCategory(HANDLE, 'Resultados da Busca')
            xbmcplugin.setContent(HANDLE, 'movies')

            for video in filtered_videos:
                tmdb_info = get_movie_info_from_tmdb(video['tmdb_id'])
                if not tmdb_info:
                    continue

                list_item = xbmcgui.ListItem(label=tmdb_info['title'])
                list_item.setArt({
                    'poster': f"https://image.tmdb.org/t/p/w500{tmdb_info['poster_path']}",
                    'fanart': f"https://image.tmdb.org/t/p/original{tmdb_info['backdrop_path']}"
                })
                info_tag = list_item.getVideoInfoTag()
                info_tag.setMediaType('movie')
                info_tag.setTitle(tmdb_info['title'])
                info_tag.setPlot(tmdb_info['overview'])
                info_tag.setYear(int(tmdb_info['release_date'].split('-')[0]) if tmdb_info.get('release_date') else 0)
                info_tag.setRating(tmdb_info.get('vote_average', 0))

                list_item.setProperty('IsPlayable', 'true')
                url = get_url(action='play', video=video['url'], movie_id=video['tmdb_id'])
                is_folder = False

                xbmcplugin.addDirectoryItem(HANDLE, url, list_item, is_folder)

            xbmcplugin.endOfDirectory(HANDLE)
        else:
            xbmcgui.Dialog().notification('Resultado', 'Nenhum filme encontrado com esse nome.', xbmcgui.NOTIFICATION_INFO)



def display_search_results(search_term):
    """
    Exibe os resultados da busca em uma pasta.
    """
    # Simulando alguns resultados de busca
    example_results = [
        {'title': 'Deadpool', 'tmdb_id': 293660, 'url': 'plugin://plugin.video.jacktorr/play_magnet?magnet=44147456d5aad8c0c026ea0b0ec2f54ec59d8c8f'},
        {'title': 'Deadpool 2', 'tmdb_id': 383498, 'url': 'plugin://plugin.video.jacktorr/play_magnet?magnet=c91ddb5653219f6f1d11d09726317bb7adbee65a'},
        {'title': 'Deadpool e Wolverine', 'tmdb_id': 533535, 'url': 'plugin://plugin.video.jacktorr/play_magnet?magnet=d5de41440647689b5d69c930bcafa8135c115bf2'},
    ]

    # Criar uma pasta para os resultados da busca
    folder_title = f'Resultados da Busca: {search_term}'
    list_item = xbmcgui.ListItem(label=folder_title)
    xbmcplugin.addDirectoryItem(HANDLE, '', list_item, isFolder=False)  # Adiciona a pasta

    # Adiciona os filmes encontrados dentro da pasta
    for movie in example_results:
        list_item = xbmcgui.ListItem(label=movie['title'])
        list_item.setProperty('IsPlayable', 'true')

        # URL para reproduzir o vídeo
        url = get_url(action='play', video=movie['url'], movie_id=movie['tmdb_id'])
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)
    
    
def router(paramstring):
    params = dict(parse_qsl(paramstring))

    if not params:
        list_categories()  # Carrega a primeira página de categorias
    elif params['action'] == 'listing':
        page = int(params.get('page', 1))  # Obtém a página atual
        category = params['category']
        
        if category == 'Gêneros':
            list_generos()
        elif category == '[COLOR gray][B]Buscar[/B][/COLOR]':
            search_movies()
        elif category == 'Coleções':
            list_colecoes()  # Nova categoria de coleções
        else:
            list_videos(category, page)
    elif params['action'] == 'listar_videos_colecao':
        colecao_nome = params['colecao']
        listar_videos_colecao(colecao_nome)  # Chama a função para listar vídeos da coleção
    elif params['action'] == 'play':
        video_url = params['video']
        movie_id = params.get('movie_id')
        play_video(video_url, movie_id)
    else:
        raise ValueError(f'Parâmetro inválido: {paramstring}!')


if __name__ == '__main__':
    router(sys.argv[2][1:])  # Inicia o roteador com os parâmetros da linha de comando


