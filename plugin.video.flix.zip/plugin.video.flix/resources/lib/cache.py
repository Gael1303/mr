import sqlite3
import time
import xbmc
import xbmcaddon
from typing import Optional

class Cache:
    def __init__(self):
        self.db_path = xbmcaddon.Addon().getAddonInfo("path") + "/cache.db"
        self.con = sqlite3.connect(self.db_path)
        self.cursor = self.con.cursor()
        self.cursor.execute(
            "CREATE TABLE IF NOT EXISTS cache(url TEXT PRIMARY KEY, response TEXT, created INT)"
        )
        self.con.commit()

    def set(self, url: str, response: str) -> None:
        try:
            self.cursor.execute(
                "INSERT OR REPLACE INTO cache(url, response, created) VALUES(?, ?, ?)",
                (url, response, int(time.time())),
            )
            self.con.commit()
        except sqlite3.Error as e:
            xbmc.log(f"Failed to write data to the sqlite table: {e}", xbmc.LOGINFO)

    def get(self, url: str) -> Optional[str]:
        try:
            self.cursor.execute("SELECT response, created FROM cache WHERE url = ?", (url,))
            return self.cursor.fetchone()
        except sqlite3.Error as e:
            xbmc.log(f"Failed to read data from the sqlite table: {e}", xbmc.LOGINFO)
        return None

    def close(self) -> None:
        self.con.close()

    def clear_cache(self) -> None:
        try:
            self.cursor.execute('DELETE FROM cache;')
            self.con.commit()
            xbmc.log("Cache cleared.", xbmc.LOGINFO)
        except sqlite3.Error as e:
            xbmc.log(f"Failed to clear cache: {e}", xbmc.LOGINFO)

    def __del__(self):
        self.close()
