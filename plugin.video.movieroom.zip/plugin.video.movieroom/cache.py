# cache.py
import os
from xbmcvfs import translatePath

# Diretório principal do addon
ADDON_PATH = translatePath('special://home/addons/plugin.video.movieroom')  # Atualize para o caminho do seu addon
CACHE_DIR = os.path.join(ADDON_PATH, 'cache')

# Verifica se o diretório de cache existe e cria se não existir
if not os.path.exists(CACHE_DIR):
    os.makedirs(CACHE_DIR)

def clear_cache():
    """Limpa o diretório de cache."""
    for filename in os.listdir(CACHE_DIR):
        file_path = os.path.join(CACHE_DIR, filename)
        try:
            if os.path.isfile(file_path):
                os.remove(file_path)
        except Exception as e:
            print(f'Erro ao remover o arquivo {file_path}: {e}')
