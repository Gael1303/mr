import os
import sys
import json
import xml.etree.ElementTree as ET
from urllib.parse import urlencode, parse_qsl
from urllib.request import urlopen

import time
import random
import xbmcaddon
import xbmcgui
import xbmcplugin
from xbmcaddon import Addon
from xbmcvfs import translatePath

# Diretório principal do addon (defina ADDON_PATH como o caminho do seu addon)
ADDON_PATH = translatePath('special://home/addons/plugin.video.movieroom')  # Atualize para o caminho do seu addon
CACHE_DIR = os.path.join(ADDON_PATH, 'cache')

# Verifica se o diretório de cache existe e cria se não existir
if not os.path.exists(CACHE_DIR):
    os.makedirs(CACHE_DIR)

# Carregar as configurações do addon
addon = xbmcaddon.Addon()

# Obter a chave da API do TMDb a partir do settings.xml
tmdb_api_key = addon.getSetting('tmdb_api_key')

# Agora você pode usar a chave para fazer suas requisições
print(f"A chave da API do TMDb é: {tmdb_api_key}")

# Adicionando as configurações do settings.xml
addon = Addon()
TMDB_API_KEY = addon.getSetting('tmdb_api_key')
VIDEOS_PER_PAGE = int(addon.getSetting('movies_per_page'))
IMAGE_QUALITY = addon.getSetting('image_quality')
INFO_URL = 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/info.txt'  # Altere para seu link

# Constants
URL = sys.argv[0]
HANDLE = int(sys.argv[1])
ADDON_PATH = translatePath(Addon().getAddonInfo('path'))
ICONS_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'icons')
FANART_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'fanart')


# GitHub URLs for different categories
RELEASES_URL = 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/news.json'
TOP_URL = 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/250.json'
HQ_URL = 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/Hq.xml'
COLLECTIONS_URL = 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/test.xml'
POPULAR_URL = 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/pop.json'

def fetch_movie_details(tmdb_id=None, imdb_id=None):
    """Fetch movie details from TMDb using either the TMDb ID or IMDb ID."""
    
    if tmdb_id:
        movie_details_url = f'https://api.themoviedb.org/3/movie/{tmdb_id}?api_key={TMDB_API_KEY}&language=pt-BR'
    elif imdb_id:
        # Exemplo de URL para buscar pelo IMDb ID
        movie_details_url = f'https://api.themoviedb.org/3/find/{imdb_id}?api_key={TMDB_API_KEY}&language=pt-BR&external_source=imdb_id'
    else:
        return {}

    try:
        with urlopen(movie_details_url) as response:
            details = json.loads(response.read().decode('utf-8'))

        # Para busca pelo IMDb ID, os detalhes estão em outra estrutura
        if imdb_id:
            details = details.get('movie_results', [])[0] if details.get('movie_results') else {}
        
        # Verifique se poster_path e backdrop_path estão disponíveis
        poster_path = details.get('poster_path')
        backdrop_path = details.get('backdrop_path')

        poster_url = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else ''
        fanart_url = f"https://image.tmdb.org/t/p/w780{backdrop_path}" if backdrop_path else ''

        genres = [genre['name'] for genre in details.get('genres', [])]

        return {
            'title': details.get('title'),
            'poster': poster_url,
            'fanart': fanart_url,
            'plot': details.get('overview'),
            'year': details.get('release_date', '')[:4],
            'duration': details.get('runtime', 0),
            'genres': genres,
            'rating': details.get('vote_average', 0),
            'vote_count': details.get('vote_count', 0)
        }
    except Exception as e:
        xbmcgui.Dialog().notification('Erro', f'Falha ao buscar detalhes do filme: {e}', time=5000)
        return {}

        
def add_menu_item(label, action, icon_url):
    url = get_url(action=action)
    list_item = xbmcgui.ListItem(label=label)
    list_item.setArt({'icon': icon_url, 'thumb': icon_url})
    xbmcplugin.addDirectoryItem(HANDLE, url, list_item, True)
        
def fetch_info_from_github():
    """Fetch information about the plugin from GitHub."""
    try:
        with urlopen(INFO_URL) as response:
            return response.read().decode('utf-8')
    except Exception as e:
        xbmcgui.Dialog().notification('Erro', f'Falha ao buscar informações: {e}', time=5000)
        return "Não foi possível carregar as informações."

def messages():
    """Display informational messages about the plugin."""
    info = fetch_info_from_github()
    dialog = xbmcgui.Dialog()
    dialog.textviewer('Informações do Plugin', info)          

def fetch_json(url):
    """Fetch JSON data from a URL using urllib."""
    with urlopen(url) as response:
        data = response.read().decode('utf-8')
    return json.loads(data)
# Carregar configurações
CACHE_EXPIRY_TIME = int(addon.getSetting('cache_expiry_time'))

def fetch_videos_from_json(url, cache_filename):
    """Fetch video data from the specified JSON URL or from cache."""
    cached_data = load_from_cache(cache_filename, expiry_time=CACHE_EXPIRY_TIME)
    if cached_data:
        return cached_data  # Retorna dados do cache

    try:
        with urlopen(url) as response:
            json_data = response.read().decode('utf-8')
            data = json.loads(json_data)
            videos = [{
                'tmdb_id': video['tmdb_id'],
                'title': video['title'],
                'url': video['url'],
                'poster': video.get('poster'),  # Adiciona o poster
                'backdrop': video.get('backdrop')  # Adiciona o backdrop
            } for video in data['videos']]


            save_to_cache(cache_filename, videos)
            return videos
    except Exception as e:
        xbmcgui.Dialog().notification('Erro', f'Falha ao buscar vídeos: {e}', time=5000)
        return []




def get_url(**kwargs):
    """Create a Kodi-compatible URL with the given query parameters."""
    return f'{URL}?{urlencode(kwargs)}'

def get_popular():
    """Get the list of releases from GitHub."""
    return fetch_json(POPULAR_URL)

def get_releases():
    """Get the list of releases from GitHub."""
    return fetch_json(RELEASES_URL)
    
def get_top():
    """Get the list of top videos from GitHub."""
    return fetch_json(TOP_URL)
    
def play_video(video_url):
    """Play a video in Kodi."""
    # Use xbmc.Player to play the video
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=video_url))
    
def get_hq():
    """Get the list of HQ videos from GitHub."""
    return fetch_json(HQ_URL)

def get_collections():
    """Get the list of collections from GitHub."""
    return fetch_json(COLLECTIONS_URL)    

def list_categories():
    """Create the list of categories in the Kodi interface."""
    xbmc.executebuiltin('Container.SetViewMode(50)')  # Define o modo de visualização como Lista
    xbmcplugin.setPluginCategory(HANDLE, 'Menu Principal')
    xbmcplugin.setContent(HANDLE, 'movies')

    # Define as categorias e suas respectivas URLs, ícones e fanart
    categories = [
        {'label': 'Principais Lançamentos', 'url': get_url(action='listing', category='releases'), 'icon': os.path.join(ICONS_DIR, 'NewReleases.png'), 'fanart': os.path.join(FANART_DIR, 'NewReleases.jpg')},
        {'label': 'Filmes Aleatórios', 'url': get_url(action='listing', category='popular'), 'icon': os.path.join(ICONS_DIR, 'popular.png'), 'fanart': os.path.join(FANART_DIR, 'popular.jpg')},
        {'label': 'Por Notas', 'url': get_url(action='listing', category='top'), 'icon': os.path.join(ICONS_DIR, 'Top.png'), 'fanart': os.path.join(FANART_DIR, 'Top.jpg')},
        {'label': '4K', 'url': get_url(action='listing', category='hq'), 'icon': os.path.join(ICONS_DIR, 'Hq.png'), 'fanart': os.path.join(FANART_DIR, 'Hq.jpg')},
        {'label': 'Coleções', 'url': get_url(action='listing', category='collections'), 'icon': os.path.join(ICONS_DIR, 'Collections.png'), 'fanart': os.path.join(FANART_DIR, 'Collections.jpg')},
        {'label': '[COLOR gray]Info![/COLOR]', 'url': get_url(action='messages'), 'icon': os.path.join(ICONS_DIR, 'Info.png'), 'fanart': os.path.join(FANART_DIR, 'Info.jpg')},
        {'label': '[COLOR darkred]Limpar Cache[/COLOR]', 'url': get_url(action='clear_cache'), 'icon': os.path.join(ICONS_DIR, 'ClearCache.png'), 'fanart': os.path.join(FANART_DIR, 'ClearCache.jpg')}
    ]

    # Adiciona cada categoria como um diretório
    for category in categories:
        list_item = xbmcgui.ListItem(label=category['label'])
        list_item.setArt({'icon': category['icon'], 'fanart': category['fanart']})
        
        # Define as propriedades de diretório
        list_item.setProperty('IsFolder', 'true')
        
        url = category['url']
        is_folder = True
        
        # Adiciona o diretório ao menu
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, is_folder)

    # Finaliza o diretório para que o Kodi entenda que o menu foi criado
    xbmcplugin.endOfDirectory(HANDLE)

# Variável global para armazenar os IDs dos filmes já exibidos
filmes_exibidos = []

def list_videos(category, page=1):
    """Create the list of playable videos for a given category in the Kodi interface."""
    xbmc.executebuiltin('Container.SetViewMode(50)')  # Define o modo de visualização como Lista
    per_page = VIDEOS_PER_PAGE
    start_index = (page - 1) * per_page
    end_index = start_index + per_page

    if category == 'releases':
        data = fetch_videos_from_json(RELEASES_URL, 'releases_cache.json')
        videos = data["videos"]  # Acessando a lista de vídeos dentro do dicionário
        xbmcplugin.setPluginCategory(HANDLE, 'Principais Lançamentos')
    elif category == 'popular':
        data = fetch_videos_from_json(POPULAR_URL, 'popular_cache.json')
        videos = data["videos"]  # Acessando a lista de vídeos
        random.shuffle(videos)  # Embaralha a lista de vídeos para a categoria Popular
        videos = [video for video in videos if video['tmdb_id'] not in filmes_exibidos]
        xbmcplugin.setPluginCategory(HANDLE, 'Aleatorios')
    elif category == 'top':
        data = fetch_videos_from_json(TOP_URL, 'top_videos_cache.json')
        videos = data["videos"]  # Acessando a lista de vídeos
        xbmcplugin.setPluginCategory(HANDLE, 'Por Notas')
    elif category == 'hq':
        data = fetch_videos_from_json(HQ_URL, 'hq_videos_cache.json')
        videos = data["videos"]
        xbmcplugin.setPluginCategory(HANDLE, '4K')
    elif category == 'collections':
        data = fetch_videos_from_json(COLLECTIONS_URL, 'collections_cache.json')
        videos = data["videos"]
        xbmcplugin.setPluginCategory(HANDLE, 'Coleções')
    else:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    xbmcplugin.setContent(HANDLE, 'movies')
    paginated_videos = videos[start_index:end_index]

    for video in paginated_videos:
        # Adiciona o ID do vídeo à lista de exibidos
        filmes_exibidos.append(video['tmdb_id'])

        # Verifica se a categoria é HQ e usa o ID do IMDb, caso contrário, usa o ID do TMDb
        if category == 'hq' and 'imdb_id' in video:
            movie_details = fetch_movie_details(imdb_id=video['imdb_id'])
        else:
            movie_details = fetch_movie_details(tmdb_id=video['tmdb_id'])

        if movie_details:
            list_item = xbmcgui.ListItem(label=movie_details['title'])
            list_item.setArt({'poster': movie_details['poster'], 'fanart': movie_details['fanart']})
            list_item.setInfo('video', {
                'title': movie_details['title'],
                'genre': ', '.join(movie_details['genres']),
                'plot': movie_details['plot'],
                'year': int(movie_details['year']),
                'duration': movie_details['duration'] * 60,
                'rating': movie_details['rating'],
                'votes': movie_details['vote_count'],
            })
            list_item.setProperty('IsPlayable', 'true')
            url = get_url(action='play', video=video['url'])
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, False)

    # Adicionando a opção de 'Próxima Página'
    if end_index < len(videos):
        next_page_url = get_url(action='listing', category=category, page=page + 1)
        next_page_item = xbmcgui.ListItem(label='Próxima Página')
        next_page_icon_url = 'https://archive.org/download/1700740365615/1700740365615.png'  # Coloque o link da imagem desejada
        next_page_item.setArt({'icon': next_page_icon_url})
        xbmcplugin.addDirectoryItem(HANDLE, next_page_url, next_page_item, True)

    # Ordenar apenas por nota se a categoria for 'top'
    if category == 'top':
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    elif category == 'releases':
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    else:
        # Não adiciona nenhum método de ordenação para "Popular"
        if category != 'popular':
            xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
            xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
            xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)

    xbmcplugin.endOfDirectory(HANDLE)

def clear_cache():
    """Clear the cache directory."""
    for file in os.listdir(CACHE_DIR):
        file_path = os.path.join(CACHE_DIR, file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
        except Exception as e:
            xbmcgui.Dialog().notification('Erro', f'Falha ao limpar o cache: {e}', time=5000)

    xbmcgui.Dialog().notification('Sucesso', 'Cache limpo com sucesso.', time=5000)

def save_to_cache(filename, data):
    """Salva dados em um arquivo de cache com um timestamp."""
    file_path = os.path.join(CACHE_DIR, filename)
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump({'timestamp': time.time(), 'data': data}, f)

def load_from_cache(filename, expiry_time=3600):
    """Carrega dados de um arquivo de cache se ainda forem válidos."""
    file_path = os.path.join(CACHE_DIR, filename)
    if os.path.exists(file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            cache = json.load(f)
            # Verifica se o cache é válido
            if time.time() - cache['timestamp'] < expiry_time:
                return cache['data']
    return None

        
def router(paramstring):
    """Router function that calls other functions based on the provided paramstring."""
    params = dict(parse_qsl(paramstring))
    if params:
        if params['action'] == 'listing':
            category = params.get('category')
            page = int(params.get('page', 1))
            list_videos(category, page)
        elif params['action'] == 'clear_cache':
            clear_cache()
        elif params['action'] == 'messages':
            messages()
        elif params['action'] == 'play':
            video_url = params.get('video')
            if video_url:
                play_video(video_url)
            else:
                xbmcgui.Dialog().notification('Erro', 'URL do vídeo não encontrada.', time=5000)
        else:
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        list_categories()


if __name__ == '__main__':
    router(sys.argv[2][1:])  # Chama o roteador