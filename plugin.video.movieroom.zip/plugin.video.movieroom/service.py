import xbmc
import xbmcaddon
import time
import json
import os
from urllib.request import urlopen
import xbmcvfs  # Importando xbmcvfs para a tradução do caminho

# Definir as URLs das listas (Lançamentos, Por Notas, etc.)
RELEASES_URL = 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/news.json'
TOP_URL = 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/250.json'
POPULAR_URL = 'https://raw.githubusercontent.com/Gael1303/mr/refs/heads/main/cat2/pop.json'

# Diretório principal do addon (defina ADDON_PATH como o caminho do seu addon)
addon = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(addon.getAddonInfo('path'))  # Usando xbmcvfs.translatePath
CACHE_DIR = os.path.join(ADDON_PATH, 'cache')

# Verifica se o diretório de cache existe e cria se não existir
if not os.path.exists(CACHE_DIR):
    os.makedirs(CACHE_DIR)

CACHE_EXPIRY_TIME = int(addon.getSetting('cache_expiry_time'))

def save_to_cache(filename, data):
    """Salva dados em um arquivo de cache com um timestamp."""
    file_path = os.path.join(CACHE_DIR, filename)
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump({'timestamp': time.time(), 'data': data}, f)

def load_from_cache(filename, expiry_time=3600):
    """Carrega dados de um arquivo de cache se ainda forem válidos."""
    file_path = os.path.join(CACHE_DIR, filename)
    if os.path.exists(file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            cache = json.load(f)
            if time.time() - cache['timestamp'] < expiry_time:
                return cache['data']
    return None

def fetch_json(url):
    """Buscar dados JSON a partir de uma URL."""
    try:
        with urlopen(url) as response:
            return json.loads(response.read().decode('utf-8'))
    except Exception as e:
        xbmc.log(f"Erro ao carregar {url}: {e}", level=xbmc.LOGERROR)
        return None

def pre_load_data():
    """Função que pré-carrega os dados das categorias e salva em cache."""
    
    # Verificar e carregar os dados de Lançamentos
    releases = load_from_cache('releases_cache.json', expiry_time=CACHE_EXPIRY_TIME)
    if not releases:
        releases = fetch_json(RELEASES_URL)
        if releases:
            save_to_cache('releases_cache.json', releases)
    
    # Verificar e carregar os dados de Top
    top_videos = load_from_cache('top_videos_cache.json', expiry_time=CACHE_EXPIRY_TIME)
    if not top_videos:
        top_videos = fetch_json(TOP_URL)
        if top_videos:
            save_to_cache('top_videos_cache.json', top_videos)
    
    # Verificar e carregar os dados de Populares
    popular_videos = load_from_cache('popular_cache.json', expiry_time=CACHE_EXPIRY_TIME)
    if not popular_videos:
        popular_videos = fetch_json(POPULAR_URL)
        if popular_videos:
            save_to_cache('popular_cache.json', popular_videos)

# Função principal que roda no serviço
def run_service():
    xbmc.log('Serviço de pré-carregamento iniciado.', level=xbmc.LOGINFO)
    
    # Aguarda o Kodi inicializar completamente antes de carregar as listas
    time.sleep(10)
    
    # Chama a função de pré-carregar os dados
    pre_load_data()
    
    xbmc.log('Pré-carregamento concluído.', level=xbmc.LOGINFO)

if __name__ == '__main__': 
    run_service()
